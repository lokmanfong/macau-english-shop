import {englishAudio} from './english-audio.mjs?v=generic60';
import {safeEnglishVoices} from './voice-choice.mjs?v=android1';
import {duckMusic} from './sound.mjs?v=shop-music2';
let chosen=localStorage.getItem('store-english-voice')||'auto',slow=localStorage.getItem('store-english-slow')==='yes',serial=0,wordPlayer=null,finishPlayback=null;
const status=text=>{const el=document.getElementById('voiceStatus');if(el)el.textContent=text;};
function voices(){return window.speechSynthesis?safeEnglishVoices(window.speechSynthesis.getVoices()):[];}
function cancelCurrent(){wordPlayer?.pause();wordPlayer=null;finishPlayback?.(false);finishPlayback=null;if(window.speechSynthesis)window.speechSynthesis.cancel();}
function populate(){const el=document.getElementById('englishVoice');if(!el)return;const available=voices();el.replaceChildren(new Option('補充文字：自動揀英文聲線','auto'));available.forEach(v=>el.append(new Option(v.name,v.voiceURI)));if(chosen!=='auto'&&!available.some(v=>v.voiceURI===chosen))chosen='auto';el.value=chosen;status('課內生字、答題鼓勵及顧客英文：內置美式音檔，毋須手機聲線。');}
async function ready(){if(voices().length||!window.speechSynthesis)return voices();await new Promise(resolve=>{const timer=setTimeout(finish,1200);function finish(){clearTimeout(timer);window.speechSynthesis.removeEventListener('voiceschanged',finish);resolve();}window.speechSynthesis.addEventListener('voiceschanged',finish);});return voices();}
export async function readEnglish(text){
 const token=++serial;cancelCurrent();const clip=englishAudio[text.trim().toLowerCase()];
 if(clip){
  const player=new Audio(new URL('assets/english/'+clip,import.meta.url));wordPlayer=player;player.playbackRate=slow?.8:1;status('內置美式英文音檔 · 毋須手機聲線');duckMusic(true);
  return new Promise(resolve=>{let done=false;const finish=(ok,message)=>{if(done)return;done=true;if(token===serial){wordPlayer=null;finishPlayback=null;duckMusic(false);if(message)status(message);}resolve(ok);};finishPlayback=ok=>finish(ok);player.onended=()=>finish(true,'內置美式英文音檔播放完成');player.onerror=()=>finish(false,'音檔未能載入，請按試聽重試。');player.play().catch(()=>finish(false,'請再撳一次發音，允許瀏覽器播放音檔。'));});
 }
 if(!window.speechSynthesis){duckMusic(false);status('呢段自訂文字未有音檔，裝置亦未提供英文聲線。');return false;}
 const available=await ready();if(token!==serial)return false;const selected=available.find(v=>v.voiceURI===chosen)||available[0];if(!selected){duckMusic(false);status('呢段自訂文字未有音檔，裝置亦未提供英文聲線。');return false;}
 const utterance=new SpeechSynthesisUtterance(text==='PE'?'P. E.':text);utterance.voice=selected;utterance.lang=selected.lang;utterance.rate=slow?.75:.9;utterance.pitch=1;status(`補充文字英文聲線 · ${selected.name}`);duckMusic(true);
 return new Promise(resolve=>{let done=false;const finish=ok=>{if(done)return;done=true;if(token===serial){finishPlayback=null;duckMusic(false);}resolve(ok);};finishPlayback=finish;utterance.onend=()=>finish(true);utterance.onerror=()=>finish(false);window.speechSynthesis.speak(utterance);});
}
export function setupVoice(){document.getElementById('englishVoice').onchange=e=>{chosen=e.target.value;localStorage.setItem('store-english-voice',chosen);};document.getElementById('slowEnglish').checked=slow;document.getElementById('slowEnglish').onchange=e=>{slow=e.target.checked;localStorage.setItem('store-english-slow',slow?'yes':'no');};document.getElementById('testEnglishVoice').onclick=()=>readEnglish('Welcome to my shop. Let us learn English.');window.speechSynthesis?.addEventListener('voiceschanged',populate);populate();}
export function stopEnglish(){serial++;cancelCurrent();duckMusic(false);}
