import {nextTrack} from './music-playlist.mjs?v=welcome-music4';
let registerEnabled=localStorage.getItem('store-register-sound')!=='off';
let speechActive=false,pendingRegister=false;
let context=null,enabled=localStorage.getItem('store-sound')!=='off',timer=null,musicBus=null;
const musicVoices=new Set();
let effectsEnabled=localStorage.getItem('store-effects')!=='off';
function ready(){context||=new (window.AudioContext||window.webkitAudioContext)();if(!musicBus){musicBus=context.createGain();musicBus.connect(context.destination);musicBus.gain.value=enabled&&!speechActive?1:0;}if(context.state!=='running')context.resume().catch(()=>{});return context;}
function tone(freq,duration=.08,delay=0,volume=.07,type='sine'){const c=ready();if(!c)return;const o=c.createOscillator(),g=c.createGain(),t=c.currentTime+delay;o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(volume,t+.008);g.gain.exponentialRampToValueAtTime(.001,t+duration);o.connect(g);g.connect(volume<.04?musicBus:c.destination);if(volume<.04){musicVoices.add(o);o.onended=()=>musicVoices.delete(o);}o.start(t);o.stop(t+duration+.01);}
export function effect(kind='tap'){if(!effectsEnabled||!(window.AudioContext||window.webkitAudioContext))return;const c=ready();if(c.state==='suspended'||c.state==='interrupted'){c.resume().then(()=>{if(effectsEnabled)playEffect(kind);}).catch(()=>{});return;}playEffect(kind);}
function playEffect(kind){if(kind==='store-upgrade'){storeUpgradeFanfare();return;}if(kind==='tap'){pop();return;}if(kind==='upgrade'){[523,659,784,1047].forEach((n,i)=>tone(n,.24,i*.11,.09,'triangle'));[523,659,784,1047].forEach(n=>tone(n,.5,.48,.045,'triangle'));return;}const sounds={tap:[660],buy:[520,780],stock:[440,660,880],sale:[784,988,1175],correct:[660,880,1047],wrong:[392,330]};(sounds[kind]||sounds.tap).forEach((n,i)=>tone(n,.12,i*.07,.065));}
function storeUpgradeFanfare(){
 // A rising fanfare, bass accents and a sustained major chord, independent of the music bus.
 const melody=[523.25,659.25,783.99,1046.5,987.77,1046.5,1318.51,1567.98];
 melody.forEach((note,i)=>tone(note,.34,i*.17,.075,'triangle'));
 [130.81,196,261.63].forEach((note,i)=>tone(note,.5,i*.42,.09,'triangle'));
 [261.63,523.25,659.25,783.99,1046.5].forEach(note=>tone(note,1.7,1.4,.045,'triangle'));
 [1567.98,2093,2637.02].forEach((note,i)=>tone(note,.65,1.55+i*.16,.04,'sine'));
}
function pop(){const c=ready();if(!c)return;const o=c.createOscillator(),g=c.createGain(),t=c.currentTime;o.type='sine';o.frequency.setValueAtTime(780,t);o.frequency.exponentialRampToValueAtTime(300,t+.075);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.075,t+.006);g.gain.exponentialRampToValueAtTime(.001,t+.105);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+.12);}
let musicTrack=0,musicPlayer=null,musicStarting=null;
function musicVolume(){if(musicPlayer)musicPlayer.volume=enabled?(speechActive?.035:.22):0;}
function getMusicPlayer(){
 if(!musicPlayer){musicPlayer=new Audio(new URL('assets/music/shop-1.wav',import.meta.url));musicPlayer.preload='auto';musicPlayer.setAttribute?.('playsinline','');musicPlayer.onended=()=>{musicPlayer.pause();musicTrack=nextTrack(musicTrack);musicPlayer.src=new URL(`assets/music/shop-${musicTrack+1}.wav`,import.meta.url).href;musicStarting=null;if(enabled)startSound();};}
 return musicPlayer;
}
export function startSound(){
 if(!enabled||document.hidden||typeof Audio==='undefined')return;
 const player=getMusicPlayer();musicVolume();if(!player.paused||musicStarting)return;
 const pending=player.play();musicStarting=pending;
 Promise.resolve(pending).catch(()=>{}).finally(()=>{if(musicStarting===pending)musicStarting=null;});
}
export function unlockAudio(){
 // Keep both operations inside a real touch/click: mobile playback policy requires a gesture.
 try{if(navigator.audioSession)navigator.audioSession.type='playback';}catch{}
 if(window.AudioContext||window.webkitAudioContext){const c=ready();if(c.createBuffer&&c.createBufferSource){const source=c.createBufferSource();source.buffer=c.createBuffer(1,1,22050);source.connect(c.destination);source.start(0);}}
 startSound();
}
export function toggleSound(){enabled=!enabled;localStorage.setItem('store-sound',enabled?'on':'off');if(enabled){unlockAudio();}else{musicPlayer?.pause();musicStarting=null;}musicVolume();return enabled;}
export function soundEnabled(){return enabled;}

export function duckMusic(muted){speechActive=muted;musicVolume();if(context&&musicBus)musicBus.gain.setTargetAtTime(muted||!enabled?0:1,context.currentTime,.08);if(!muted&&pendingRegister){pendingRegister=false;if(document.querySelector('main')?.dataset.view==='shop')registerSound();}}

let registerPlayer=null,registerPrimed=false,registerPriming=false,registerSequence=0;
function registerStatus(text){const node=document.getElementById?.('checkoutSoundStatus');if(node)node.textContent=text;}
function registerAudio(){if(!registerPlayer){registerPlayer=new Audio(new URL('assets/register_sale.wav',import.meta.url));registerPlayer.preload='auto';registerPlayer.volume=.9;}return registerPlayer;}
export function registerSound(){
 if(!registerEnabled)return;if(speechActive){pendingRegister=true;return;}if(document.querySelector('main')?.dataset.view!=='shop')return;
 const audio=registerAudio(),sequence=++registerSequence;registerPrimed=true;audio.pause();audio.currentTime=0;audio.volume=.9;registerStatus('正在播放收銀音效…');
 audio.onended=()=>{if(sequence===registerSequence)registerStatus('收銀音效已播放完成');};audio.onerror=()=>registerStatus('收銀音效未能載入，請按「試聽收銀聲」重試。');
 audio.play().then(()=>{registerPrimed=true;registerStatus('收銀音效播放中');}).catch(()=>{registerPrimed=false;registerStatus('收銀聲被瀏覽器暫停，請按「試聽收銀聲」啟動。');});
}
export function stopRegisterSound(){pendingRegister=false;registerSequence++;registerPlayer?.pause();if(registerPlayer)registerPlayer.currentTime=0;}
export function unlockRegisterSound(){
 if(registerPrimed||registerPriming||!registerEnabled)return;registerPriming=true;const audio=registerAudio(),sequence=registerSequence;audio.volume=0;
 audio.play().then(()=>{registerPrimed=true;if(sequence===registerSequence){audio.pause();audio.currentTime=0;audio.volume=.9;}}).catch(()=>{}).finally(()=>registerPriming=false);
}
export function registerSoundEnabled(){return registerEnabled;}
export function setRegisterSoundEnabled(value){registerEnabled=!!value;localStorage.setItem('store-register-sound',registerEnabled?'on':'off');if(!registerEnabled)stopRegisterSound();}

export function effectsOn(){return effectsEnabled;}
export function setEffects(value){effectsEnabled=!!value;localStorage.setItem('store-effects',effectsEnabled?'on':'off');}
